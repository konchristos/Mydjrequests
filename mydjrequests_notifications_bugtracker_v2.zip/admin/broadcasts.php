<?php
require_once __DIR__ . '/../app/bootstrap.php';
require_admin();

$pageTitle = 'Broadcasts';
$pageBodyClass = 'admin-page';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token()) {
        $error = 'Invalid session. Please refresh.';
    } else {
        $title = trim($_POST['title'] ?? '');
        $body = trim($_POST['body'] ?? '');
        $url = trim($_POST['url'] ?? '');

        if ($title === '' || $body === '') {
            $error = 'Title and message are required.';
        } else {
            $nid = notifications_create('broadcast', $title, $body, $url);
            notifications_add_all_users($nid);
            $success = 'Broadcast sent to all users.';
        }
    }
}

// Show recent broadcasts (last 20)
$db = db();
$rows = $db->query("SELECT * FROM notifications WHERE type = 'broadcast' ORDER BY created_at DESC LIMIT 20")
    ->fetchAll(PDO::FETCH_ASSOC);

include APP_ROOT . '/dj/layout.php';
?>

<style>
.form-card { background:#111116; border:1px solid #1f1f29; border-radius:12px; padding:20px; max-width:900px; }
label { display:block; margin:10px 0 6px; color:#cfcfd8; }
input, textarea { width:100%; padding:10px; border-radius:8px; border:1px solid #2a2a38; background:#0f0f14; color:#fff; }
.btn-primary { background:#ff2fd2; color:#fff; border:none; padding:10px 14px; border-radius:8px; font-weight:600; cursor:pointer; }
.error { color:#ff8080; }
.success { color:#7be87f; }

.broadcast-table { width:100%; border-collapse:collapse; margin-top:16px; }
.broadcast-table th, .broadcast-table td { padding:10px; border-bottom:1px solid rgba(255,255,255,0.08); text-align:left; }
</style>

<div class="admin-wrap">
    <h1>Broadcasts</h1>

    <?php if ($error): ?><div class="error"><?php echo e($error); ?></div><?php endif; ?>
    <?php if ($success): ?><div class="success"><?php echo e($success); ?></div><?php endif; ?>

    <div class="form-card">
        <form method="POST">
            <?php echo csrf_field(); ?>
            <label for="title">Title</label>
            <input id="title" name="title" type="text" required>

            <label for="body">Message</label>
            <textarea id="body" name="body" rows="4" required></textarea>

            <label for="url">Link (optional)</label>
            <input id="url" name="url" type="text" placeholder="/dj/dashboard.php">

            <button class="btn-primary" type="submit">Send Broadcast</button>
        </form>
    </div>

    <table class="broadcast-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Message</th>
                <th>Created</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($rows as $r): ?>
            <tr>
                <td>#<?php echo (int)$r['id']; ?></td>
                <td><?php echo e($r['title']); ?></td>
                <td><?php echo e($r['body']); ?></td>
                <td><?php echo e($r['created_at']); ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
